<?php return array (
  'blade-ui-kit/blade-icons' => 
  array (
    'providers' => 
    array (
      0 => 'BladeUI\\Icons\\BladeIconsServiceProvider',
    ),
  ),
  'codeat3/blade-elusive-icons' => 
  array (
    'providers' => 
    array (
      0 => 'Codeat3\\BladeElusiveIcons\\BladeElusiveIconsServiceProvider',
    ),
  ),
  'codeat3/blade-teeny-icons' => 
  array (
    'providers' => 
    array (
      0 => 'Codeat3\\BladeTeenyIcons\\BladeTeenyIconsServiceProvider',
    ),
  ),
  'codeat3/blade-vaadin-icons' => 
  array (
    'providers' => 
    array (
      0 => 'Codeat3\\BladeVaadinIcons\\BladeVaadinIconsServiceProvider',
    ),
  ),
  'facade/ignition' => 
  array (
    'providers' => 
    array (
      0 => 'Facade\\Ignition\\IgnitionServiceProvider',
    ),
    'aliases' => 
    array (
      'Flare' => 'Facade\\Ignition\\Facades\\Flare',
    ),
  ),
  'fruitcake/laravel-cors' => 
  array (
    'providers' => 
    array (
      0 => 'Fruitcake\\Cors\\CorsServiceProvider',
    ),
  ),
  'laravel/sail' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Sail\\SailServiceProvider',
    ),
  ),
  'laravel/sanctum' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Sanctum\\SanctumServiceProvider',
    ),
  ),
  'laravel/tinker' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Tinker\\TinkerServiceProvider',
    ),
  ),
  'nesbot/carbon' => 
  array (
    'providers' => 
    array (
      0 => 'Carbon\\Laravel\\ServiceProvider',
    ),
  ),
  'nunomaduro/collision' => 
  array (
    'providers' => 
    array (
      0 => 'NunoMaduro\\Collision\\Adapters\\Laravel\\CollisionServiceProvider',
    ),
  ),
  'owenvoke/blade-fontawesome' => 
  array (
    'providers' => 
    array (
      0 => 'OwenVoke\\BladeFontAwesome\\BladeFontAwesomeServiceProvider',
    ),
  ),
);